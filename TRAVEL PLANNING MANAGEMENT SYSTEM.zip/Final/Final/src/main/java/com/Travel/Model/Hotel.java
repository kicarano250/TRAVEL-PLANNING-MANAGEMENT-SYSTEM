package com.Travel.Model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Hotel {
	@Id
	private String HotelName;
	private String Province;
	private String Distric;
	private String Rate;
	private double price;
	public String getHotelName() {
		return HotelName;
	}
	public void setHotelName(String hotelName) {
		HotelName = hotelName;
	}
	public String getProvince() {
		return Province;
	}
	public void setProvince(String province) {
		Province = province;
	}
	public String getDistric() {
		return Distric;
	}
	public void setDistric(String distric) {
		Distric = distric;
	}
	public String getRate() {
		return Rate;
	}
	public void setRate(String rate) {
		Rate = rate;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Hotel(String hotelName, String province, String distric, String rate, double price) {
		super();
		HotelName = hotelName;
		Province = province;
		Distric = distric;
		Rate = rate;
		this.price = price;
	}
	public Hotel() {
		
	}
	
	
	
	
	

}
