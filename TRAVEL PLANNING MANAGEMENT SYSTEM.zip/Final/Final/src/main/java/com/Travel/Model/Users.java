package com.Travel.Model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Users {
	@Id
	private int IdNumber;
	private String Name;
	private String Email;
	private String Password;
	private String Contact;
	private int BankAccount;
	public int getIdNumber() {
		return IdNumber;
	}
	public void setIdNumber(int idNumber) {
		IdNumber = idNumber;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getContact() {
		return Contact;
	}
	public void setContact(String contact) {
		Contact = contact;
	}
	public int getBankAccount() {
		return BankAccount;
	}
	public void setBankAccount(int bankAccount) {
		BankAccount = bankAccount;
	}
	public Users(int idNumber, String name, String email, String password, String contact, int bankAccount) {
		super();
		IdNumber = idNumber;
		Name = name;
		Email = email;
		Password = password;
		Contact = contact;
		BankAccount = bankAccount;
	}
	public Users() {
		
	}
	

}
