package com.Travel.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.Travel.Dao.BookingDao;
import com.Travel.Dao.HotelDao;
import com.Travel.Model.Booking;
import com.Travel.Model.Hotel;
import com.Travel.Service.BookingService;
import com.Travel.Service.HotelService;

public class HotelController {
	@Autowired
	HotelDao repo;
	
	@Autowired
	 HotelService service;
	@RequestMapping("/hotel")
	public String home() {
		return "index";
	}
	
	@RequestMapping("/addHotel")
	public String addhotel(Hotel hotel)
	{
		repo.save(hotel);
		
		return "index";
	}
	
	@RequestMapping("/getHotel")
	public ModelAndView  getHotel(@RequestParam int aid)
	{
		ModelAndView mv=new ModelAndView("Offers");
		Hotel alien=repo.findById(aid).orElse(new Hotel());
		mv.addObject(alien);
		return mv;
	} 
	@RequestMapping("/getAllhotel")
	@ResponseBody
	public ModelAndView getAndView() 
	
	{
		ModelAndView mv=new ModelAndView("list");
		
		List<Hotel> result=(List<Hotel>) repo.findAll();
		mv.addObject(result);
		
			return mv;
		
	} 
	@RequestMapping("/allHotel")
	@ResponseBody
	public List<Hotel> getBookings() {
		
		return repo.findAll();
	}

}
