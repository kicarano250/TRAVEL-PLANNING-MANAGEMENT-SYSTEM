package com.Travel.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Travel.Dao.BookingDao;
import com.Travel.Dao.UsersDao;

@Service
public class UserService {
	@Autowired
	UsersDao repo;

}
