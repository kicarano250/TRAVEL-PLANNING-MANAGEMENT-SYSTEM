package com.Travel.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Travel.Model.Booking;
import com.Travel.Model.Hotel;

public interface HotelDao extends JpaRepository<Hotel, Integer> {

}
