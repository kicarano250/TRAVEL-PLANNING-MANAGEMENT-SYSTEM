package com.Travel.Model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Booking implements Serializable {
	@Id
private int BookingId;
private Date BookingDate;
private String Location;
@ManyToOne
@JoinColumn(name="HotelName")
private Hotel hotel;
@ManyToOne
@JoinColumn(name="IdNumber")
private Users users;
public int getBookingId() {
	return BookingId;
}
public void setBookingId(int bookingId) {
	BookingId = bookingId;
}
public Date getBookingDate() {
	return BookingDate;
}
public void setBookingDate(Date bookingDate) {
	BookingDate = bookingDate;
}
public String getLocation() {
	return Location;
}
public void setLocation(String location) {
	Location = location;
}
public Hotel getHotel() {
	return hotel;
}
public void setHotel(Hotel hotel) {
	this.hotel = hotel;
}
public Users getUsers() {
	return users;
}
public void setUsers(Users users) {
	this.users = users;
}
public Booking(int bookingId, Date bookingDate, String location, Hotel hotel, Users users) {
	super();
	BookingId = bookingId;
	BookingDate = bookingDate;
	Location = location;
	this.hotel = hotel;
	this.users = users;
}
public Booking() {
	super();
}





}
