package com.Travel.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Travel.Model.Booking;
import com.Travel.Model.Users;

public interface UsersDao extends JpaRepository<Users, Integer> {

}
