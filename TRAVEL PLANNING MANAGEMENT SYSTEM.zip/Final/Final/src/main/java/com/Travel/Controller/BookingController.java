package com.Travel.Controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.Travel.Dao.BookingDao;
import com.Travel.Model.Booking;
import com.Travel.Service.BookingService;


@Controller

public class BookingController {
	@Autowired
	BookingDao repo;
	
	@Autowired
	 BookingService service;
	
	@RequestMapping("/")
	public String home() {
		return "Rubavu";
	}
	
	@RequestMapping("/addBooking")
	public String addAlien(Booking booking)
	{
		repo.save(booking);
		
		return "index";
	}
	
	@RequestMapping("/getBooking")
	public ModelAndView  getAlien(@RequestParam int aid)
	{
		ModelAndView mv=new ModelAndView("Offers");
		Booking alien=repo.findById(aid).orElse(new Booking());
		mv.addObject(alien);
		return mv;
	} 
	@RequestMapping("/getAllBooikingn")
	@ResponseBody
	public ModelAndView getAndView() 
	
	{
		ModelAndView mv=new ModelAndView("list");
		
		List<Booking> result=(List<Booking>) repo.findAll();
		mv.addObject(result);
		
			return mv;
		
	} 
	@RequestMapping("/allBooking")
	@ResponseBody
	public List<Booking> getBookings() {
		
		return repo.findAll();
	}

}
