package com.Travel.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Travel.Dao.BookingDao;
import com.Travel.Dao.HotelDao;
import com.Travel.Model.Booking;
import com.Travel.Model.Hotel;

@Service
public class HotelService {
	
	private final HotelDao  repo;

    @Autowired
    public HotelService(HotelDao repo) {
        this.repo = repo;
    }

    
    
    public void createhotel(Hotel hotel ) {
		
		
		 repo.save(hotel);
		
	}

   public List<Hotel> getAllhotel() {
       return repo.findAll();
   }

   public Optional<Hotel> getEntityById(int id) {
       return repo.findById(id);
   }

//   
//   public Booking updateEntity(int id, Booking updatedEntity) {
//       Optional<Booking> existingEntityOptional = repo.findById(id);
//       if (existingEntityOptional.isPresent()) {
//       	Booking existingEntity = existingEntityOptional.get();
//           // Update the fields of existingEntity with the fields from updatedEntity
//           existingEntity.setField1(updatedEntity.getBookingId());
//           existingEntity.setField2(updatedEntity.getField2());
//           // ... update other fields as needed
//           return yourEntityRepository.save(existingEntity);
//       } else {
//           // Handle the case where the entity with the given id does not exist
//           // You can throw an exception or return null/empty object, depending on your preference
//           throw new EntityNotFoundException("Entity not found with id: " + id);
//       }
   //}

   public void deleteEntity(int id) {
       repo.deleteById(id);
   }
}
